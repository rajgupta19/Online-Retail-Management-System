import mysql.connector
import random
import string

sql_net=mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    passwd="raj1912",
    database = "ORS"

)

cursor = sql_net.cursor()
sql_net.autocommit=True

def supplier_menu():
    while True:
        print("1. Add Product")
        print("2. Logout")
        choice = input("Enter Your Choice: ")
        if choice == '1':
            add_product()
        elif choice == '2':
            print("Logging Out...")
            break
        else:
            print("Invalid Choice")
            supplier_menu()

def add_product():
    

    #PRODUCT_NAME, PRODUCT_ID, BRAND, MRP, STOCK, EXPIRY_DATE, MANUFACTURING_DATE, CATEGORY_ID

    product_Name = input("Enter Product Name : ")
    product_id = input("Enter Product Id : ")
    product_Brand = input("Enter Product Brand : ")
    product_Mrp = input("Enter Product MRP : ")
    product_Stock = input("Enter Product Stock: ")
    product_expirydate = input("Enter Product Expiry Date : ")
    product_Manufacturing = input("Enter manufacturing date : ")
    product_CATEGORYID= input("Enter Product category id : ")
    


    query = f"INSERT INTO Product (PRODUCT_NAME, PRODUCT_ID, BRAND, MRP, STOCK, EXPIRY_DATE, MANUFACTURING_DATE, CATEGORY_ID) VALUES ('{product_Name}', '{product_id}', '{product_Brand}', '{product_Mrp}', '{product_Stock}', '{product_expirydate}','{product_Manufacturing}', '{product_CATEGORYID}')"
    cursor.execute(query)
    print("Product Added Successfully!")
    supplier_menu()
