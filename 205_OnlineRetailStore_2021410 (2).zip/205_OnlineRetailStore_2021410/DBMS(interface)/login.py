import mysql.connector
from Customer import *
from supplier import *
from admin import *

sql_net=mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    passwd="raj1912",
    database = "ORS"
)
cursor = sql_net.cursor()
sql_net.autocommit=True

def login():
    print("1. Login as Customer")
    print("2. Login as supplier")
    print("3. Login as Admin")
    print("4. Back")
    choice = input("Enter your choice : ")
    if choice == "1":
        customer_login()
    elif choice == "2":
        Supplier_login()
    elif choice == "3":
        admin_login()
    elif choice == "4":
        print("Returning...")
    else:
        print("Invalid choice. Please enter a number between 1 and 4.")
        login()

def Supplier_login():
    Supplier_username = input("Enter Supplier Id: ")
    Supplier_password = input("Enter Supplier Password: ")
    cursor.execute("SELECT * FROM Supplier WHERE S_ID = %s ", (Supplier_username,))
    Supplier = cursor.fetchone()
    if Supplier:
        print("Supplier Logged in Successfully!")
        supplier_menu()
    else:
        print("Invalid Login Credentials")
        Supplier_login()
                                                                                                                                                                                                                                                                                                                                                                             
def customer_login():
    user_name=input("Enter Customer Id : ")
    user_password=input("Enter password: ")
    cursor.execute("SELECT CUSTOMER_ID FROM Customer WHERE CUSTOMER_ID = %s", (user_name,))
    user = cursor.fetchone()
    if user:
        print("User Logged in Successfully!")
        user_menu(user[0])
    else:
        print("Invalid Login Credentials")
        customer_login()


def admin_login():
    admin_name=input("Enter user name: ")
    admin_password=input("Enter password: ")
    cursor.execute("SELECT * FROM Admin WHERE USERNAME = %s AND PASSWORD = %s", (admin_name,admin_password))
    user = cursor.fetchone()
    if user:
        print("Admin Logged in Successfully!")
        admin_menu()
    else:
        print("Invalid Login Credentials")
        admin_login()
