import mysql.connector

sql_net=mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    passwd="raj1912",
    database = "ORS"
    )
cursor = sql_net.cursor()
sql_net.autocommit=True
cursor = sql_net.cursor(buffered=True)

def user_menu(CUSTOMER_ID):
    print("Welcome to the Customer menu!\n")
    while True:
        print("Please choose an option:")
        print("1. View products")
        print("2. Add item to cart")
        print("3. View cart" )
        print("4. Remove item from cart")
        print("5. Place order")
        print("6. View orders")
        print("7. Logout")
        choice = input("Enter your choice: ")
        if choice == "1":
            view_products()
        elif choice == "2":
            add_to_cart(CUSTOMER_ID)
        elif choice == "3":
            view_cart(CUSTOMER_ID)
        elif choice == "4":
            remove_from_cart()
        elif choice == "5":
            place_order(CUSTOMER_ID)
        elif choice == "6":
            view_orders(CUSTOMER_ID)
        elif choice == "7":
            print("Logging Out...")
            break
        else:
            print("Invalid choice. Please try again.\n")

def view_products():
    cursor.execute("SELECT * FROM ors.product")
    products = cursor.fetchall()
    print("Available products:")
    for product in products:
        print(f"PRODUCT_NAME: {product[0]}, PRODUCT_ID: {product[1]}, BRAND: {product[2]}, MRP: {product[3]}, STOCK: {product[4]}, EXPIRY_DATE: {product[5]}, MANUFACTURING_DATE: {product[6]}, CATEGORY_ID:{product[7]}")
    print()


def add_to_cart(CUSTOMER_ID):
    # Get the product details from the user
    product_id = input("Enter the product ID: ")
    quantity = int(input("Enter the quantity: "))

    # Check if the product is in stock
    cursor.execute("SELECT STOCK FROM Product WHERE PRODUCT_ID = %s", (product_id,))
    stock = cursor.fetchone()[0]
    if stock < quantity:
        print("Sorry, the requested quantity is not available in stock.")
        return

    # get the current cart details
    cursor.execute("SELECT CART_ID, TOTAL_AMOUNT, TOTAL_QUANTITY FROM Cart WHERE CUSTOMER_ID = %s", (CUSTOMER_ID,))
    cart_details = cursor.fetchone()
    if cart_details is None:
        # create a new cart if one does not exist
        cursor.execute("INSERT INTO Cart (TOTAL_AMOUNT, TOTAL_QUANTITY, CUSTOMER_ID) VALUES (%s, %s, %s)", (0, 0, CUSTOMER_ID))

        CART_ID = cursor.lastrowid
        total_amount = 0
        total_quantity = 0
    else:
        # update the existing cart details
        CART_ID = cart_details[0]
        total_amount = cart_details[1]
        total_quantity = cart_details[2]

    
    # get the product details
    cursor.execute("SELECT PRODUCT_NAME, MRP FROM Product WHERE PRODUCT_ID = %s", (product_id,))
    product_details = cursor.fetchone()
    product_name = product_details[0]
    product_price = product_details[1]
    product = cursor.fetchall()

    cursor.execute("SELECT MAX(CART_ID) FROM Cart")
    cart_id = cursor.fetchone()[0]
    cart_id = int(cart_id)
    cart_id += 1
    print(cart_id)

    new_total_quantity = total_quantity + quantity
    new_total_amount = total_amount + (product_price * quantity)

    # add the product to the cart

    cursor.execute("INSERT INTO Cart (CART_ID,TOTAL_AMOUNT, TOTAL_QUANTITY, CUSTOMER_ID) VALUES (%s, %s, %s, %s )", (cart_id, new_total_amount, new_total_quantity, CUSTOMER_ID))

    # update the cart details
    cursor.execute("UPDATE Cart SET TOTAL_AMOUNT = %s, TOTAL_QUANTITY = %s WHERE CART_ID = %s", (new_total_amount, new_total_quantity, CART_ID))

    print(f"{quantity} {product_name} added to cart successfully!")
    print(f"Cart Total: ₹{new_total_amount} ({new_total_quantity} items)")


def view_cart(CUSTOMER_ID):
    # Get the cart items for the given customer ID
    cursor.execute(f"SELECT * FROM Cart WHERE CUSTOMER_ID = {CUSTOMER_ID}")
    cart_items = cursor.fetchall()
    print(cart_items)
    # Ask user if they want to continue shopping
    while True:
        checkout_choice = input("Enter 's' to continue shopping: ")
        if checkout_choice.lower() == "s":
            user_menu(CUSTOMER_ID)
            break
        else:
            print("Invalid choice Press 's' to continue shopping.")

def remove_from_cart():
    print("|REMOVE PRODUCT|")
    print(" Products Available: ")
    cursor.execute("select * from Cart")
    info=cursor.fetchall()
    for x in info:
        j="'"+input("Enter cart  id : ")+"'"
        cursor.execute("select TOTAL_QUANTITY from Cart where CART_ID={};".format(j))
        j1=cursor.fetchall()
        k="'"+str((int(j1[0][0]))-int(input('ENTER QUANTITY : ')))+"'"
        if k=="'0'":
            cursor.execute("delete from Cart wherewhere CART_ID={};".format(j))
            print("updated")
        else:
            cursor.execute('update Cart set TOTAL_QUANTITY={} where CART_ID={} ;'.format(k,j))
            print ("Updated\n")   
            break  
    else:
        print("Product not found")   



def apply_coupon(CUSTOMER_ID, coupon_code):
    cursor.execute("SELECT * FROM Coupons WHERE CUSTOMER_ID = %s AND COUPON_ID = %s", (CUSTOMER_ID, coupon_code))
    coupon = cursor.fetchone()
    if not coupon:
        print("Invalid coupon code.")
        return 0
    elif coupon[2]:
        print("Coupon code has already been used.")
        return 0
    else:
        discount = coupon[1] / 100
        cursor.execute("UPDATE Coupons SET USED = TRUE WHERE CUSTOMER_ID = %s AND COUPON_ID = %s", (CUSTOMER_ID, coupon_code))
        print(f"Coupon applied successfully. Discount of {coupon[1]}% applied.")
        return discount

def place_order(CUSTOMER_ID):
    print("|PLACE ORDER|")
    # Retrieve cart items
    cursor.execute("SELECT * FROM Cart WHERE CUSTOMER_ID = %s", (CUSTOMER_ID,))
    cart_items = cursor.fetchall()
    # print(cart_items)
    if not cart_items:
        print("Cart is empty.")
        return
    # Display cart items and calculate total amount
    total_amount = 0
    for item in cart_items :
        product_id = item[0]
        quantity = item[2]
        cursor.execute("SELECT PRODUCT_NAME, MRP FROM Product WHERE PRODUCT_ID = %s", (product_id,))
        product_info = cursor.fetchone()
        if not product_info:
            continue
        product_name = product_info[0]
        mrp = product_info[1]
        item_amount = item[1]
        total_amount += item_amount
    print(f"Total amount: Rs. {total_amount}")
    # Apply coupon if available
    coupon_code = input("Enter coupon code (if available): ")
    discount = apply_coupon(CUSTOMER_ID, coupon_code)
    # Calculate final amount after discount
    final_amount = total_amount - (total_amount * float(discount))
    print(f"Final amount after discount: Rs. {final_amount:.2f}")
    # Confirm order placement
    confirm = input("Place order? (y/n) ")
    if confirm.lower() == "y":
        # Update inventory and delete cart items
        for item in cart_items:
            product_id = item[1]
            quantity = item[3]
            cursor.execute("UPDATE Inventory SET QUANTITY = QUANTITY - %s WHERE PRODUCT_ID = %s", (quantity, product_id))
           
            cursor.execute("DELETE FROM Cart WHERE CART_ID = %s", (item[0],))
        
    
        print("WOW! Order placed successfully.")
    else:
        print("OOPS! Order not placed.")


def view_orders(CUSTOMER_ID):
    cursor.execute("SELECT * FROM Orders WHERE CUSTOMER_ID = %s", (CUSTOMER_ID,))
    orders = cursor.fetchall()
    print(orders)