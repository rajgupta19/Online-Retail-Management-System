import mysql.connector
mydb = mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    passwd="raj1912",
    database = "ORS"
)

cursor = mydb.cursor()
mydb.autocommit=True


def admin_menu():
    while True:
        print("1. Update product")
        print("2. Delete user")
        print("3. Delete Product")
        print("4. Add Product")
        print("5. Logout")

        choice = input("Enter Your Choice: ")
        if choice == '1':
            update_product()
        elif choice == '2':
            delete_customer()
        elif choice == "3":
            delete_product()
        elif choice == "4":
            add_product()  
        elif choice == "5":
            print("Logging Out")
            break
        else:
            print("Invalid Choice")
            admin_menu()


def update_product():
    product_id = input("Enter Product ID: ")
    cursor.execute("SELECT * FROM product WHERE PRODUCT_ID = %s", (product_id,))
    product = cursor.fetchone()
    if product:
        print("1. Update Product Name")
        print("2. Update Product MRP")
        print("3. Update Product Stock")
        print("4. Back to Admin Menu")
        choice = input("Enter Your Choice: ")
        if choice == '1':
            product_name = input("Enter New Product Name: ")
            cursor.execute("UPDATE Product SET PRODUCT_NAME = %s WHERE PRODUCT_ID = %s", (product_name, product_id))
            mydb.commit()
            print("Product Name Updated Successfully!")
            update_product()
    
        elif choice == '2':
            product_price = input("Enter New Product MRP: ")
            cursor.execute("UPDATE Product SET MRP = %s WHERE PRODUCT_ID = %s", (product_price, product_id))
            mydb.commit()
            print("Product Price Updated Successfully!")
            update_product()
       
        elif choice == '3':
            product_stock = input("Enter New stock ")
            cursor.execute("UPDATE Product SET STOCK = %s WHERE PRODUCT_ID = %s", (product_stock, product_id))
            mydb.commit()
            print("Product expiry date Updated Successfully!")
            update_product()

    
        elif choice=="4":
            admin_menu()

def delete_customer():
    delete=int(input("Enter Customer ID to be deleted: "))
    cursor.execute(f"DELETE FROM Payment WHERE CUSTOMER_ID={delete}")
    cursor.execute(f"DELETE FROM Review WHERE CUSTOMER_ID={delete}")
    cursor.execute(f"DELETE FROM Cart WHERE CUSTOMER_ID={delete}")
    cursor.execute(f"DELETE FROM Coupons WHERE CUSTOMER_ID={delete}")
    
    print("User deleted successfully!")



def delete_product():
    delete=int(input("Enter product ID to be deleted: "))
    cursor.execute(f"DELETE FROM OrderItem WHERE PRODUCT_ID={delete}")
    cursor.execute(f"DELETE FROM Inventory WHERE PRODUCT_ID={delete}")
    print("Product deleted successfully!")


def add_product():
    

    #PRODUCT_NAME, PRODUCT_ID, BRAND, MRP, STOCK, EXPIRY_DATE, MANUFACTURING_DATE, CATEGORY_ID

    product_Name = input("Enter Product Name : ")
    product_id = input("Enter Product Id : ")
    product_Brand = input("Enter Product Brand : ")
    product_Mrp = input("Enter Product MRP : ")
    product_Stock = input("Enter Product Stock: ")
    product_expirydate = input("Enter Product Expiry Date : ")
    product_Manufacturing = input("Enter manufacturing date : ")
    product_CATEGORYID= input("Enter Product category id : ")
    


    query = f"INSERT INTO Product (PRODUCT_NAME, PRODUCT_ID, BRAND, MRP, STOCK, EXPIRY_DATE, MANUFACTURING_DATE, CATEGORY_ID) VALUES ('{product_Name}', '{product_id}', '{product_Brand}', '{product_Mrp}', '{product_Stock}', '{product_expirydate}','{product_Manufacturing}', '{product_CATEGORYID}')"
    cursor.execute(query)
    print("Product Added Successfully!")
