import mysql.connector
from login import *  
from Signup import * 
sql_net=mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    passwd="raj1912",
    database = "ORS")
def main():
    while True:
        print("welcome to our application !! ")
        print("1. Login")
        print("2. SignUp")
        print("3. Exit")
        choice = input("Enter your choice : ")
        if choice == "1":
            login()
        elif choice == "2":
            SignUp()
        elif choice == "3":
            break
        else:
            print("Invalid")

main()