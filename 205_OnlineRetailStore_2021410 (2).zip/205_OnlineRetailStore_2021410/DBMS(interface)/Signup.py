import mysql.connector
from supplier import *
from Customer import * 
sql_net=mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    passwd="raj1912",
    database = "ORS"
)

cursor = sql_net.cursor()
sql_net.autocommit = True

def SignUp():
    print("1. SignUp as Customer")
    print("2. SignUp as Supplier")
    print("3. Back")
    choice = input("Enter your choice : ")
    if choice == "1":
        SignUp_Customer()
    elif choice == "2":
        SignUp_Supplier()
    elif choice == "3":
        print("Returning...")
        
    else:
        print("Invalid choice. Please enter a number between 1 and 3.")
        SignUp()

def SignUp_Customer():
    print("Please enter the following details:")
    customer_id = input("Customer Id :")
    Customer_number = input("Customer Phone Number: ")
    Customer_dob = input("Customer dob: ")
    Customer_FirstName = input("Customer First Name: ")
    Customer_MiddleName = input("Customer Middle Name: ")
    Customer_LastName = input("Customer Last Name: ")
    Customer_age = input("Customer age: ")

    
    query = f"INSERT INTO customer(CUSTOMER_ID, PHONE_NUMBER, DATE_OF_BIRTH, FIRST_NAME, MIDDLE_NAME, LAST_NAME, AGE) VALUES ('{customer_id}','{Customer_number}','{Customer_dob}','{Customer_FirstName}', '{Customer_MiddleName}','{Customer_LastName}','{Customer_age}')"
    cursor.execute(query)
    print("Customer registered successfully!")
    user_menu()


def SignUp_Supplier():
    print("Please enter the following details:")
    Supplier_FirstName = input("Supplier First Name: ")
    Supplier_LastName = input("Supplier Last Name: ")
    Supplier_Address = input("Supplier Address: ")
    Supplier_Pincode = input("Supplier Pincode : ")
    Supplier_number = input("Supplier Phone Number: ")
    Supplier_age = input("Supplier age: ")

    query = f"INSERT INTO supplier (`Supplier First Name`, `Supplier Last Name`, `Supplier Address`, `Suppliers Pincode`, `Suppliers Phone No.`, `Suppliers Age`) VALUES ('{Supplier_FirstName}', '{Supplier_LastName}', '{Supplier_Address}' , '{Supplier_Pincode}', '{Supplier_number}', '{Supplier_age}')"
    cursor.execute(query)
    print("Supplier registered successfully!")
    supplier_menu()
    

